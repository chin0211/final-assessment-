const tableBody = document.getElementById('instrumentTable').getElementsByTagName('tbody')[0];
let latestData = {};
let allData = [];
let currentPage = 1;
const rowsPerPage = 8;
const rowMap = new Map();
let filteredData = [];
let intervalId;

function fetchData() {
    fetch('http://18.143.79.95/api/priceData/technical-test')
        .then(response => response.json())
        .then(data => {
            allData = data;
            allData.sort((a, b) => {
                const symbolA = (a.symbol || a.Symbol || a.name || 'N/A').toUpperCase();
                const symbolB = (b.symbol || b.Symbol || b.name || 'N/A').toUpperCase();
                return symbolA.localeCompare(symbolB);
            });
            if (filteredData.length === 0 || document.getElementById('searchInput').value.trim() === '') {
                filteredData = [...allData];
            }
            updateTable();
        })
        .catch(error => console.error('Error fetching data:', error));
}

function updateTable() {
    const startIndex = (currentPage - 1) * rowsPerPage;
    const endIndex = startIndex + rowsPerPage;
    const pageData = filteredData.slice(startIndex, endIndex);

    pageData.forEach(item => {
        const symbol = item.symbol || item.Symbol || item.name || 'N/A';
        const bid = parseFloat(item.bid || item.Bid || item.buy || 0);
        const ask = parseFloat(item.ask || item.Ask || item.sell || 0);
        let dailyChange = item.dailyChange || item.Spread || 'N/A';

        if (typeof dailyChange === 'number') {
            dailyChange = dailyChange.toFixed(2);
        }

        let row = rowMap.get(symbol);
        if (!row) {
            row = tableBody.insertRow();
            rowMap.set(symbol, row);
            row.insertCell(0);
            row.insertCell(1);
            row.insertCell(2);
            row.insertCell(3);
        }

        row.cells[0].textContent = symbol;
        row.cells[3].innerHTML = getDailyChangeCell(dailyChange, latestData[symbol] ? latestData[symbol].dailyChange : dailyChange);
        row.cells[1].innerHTML = getPriceCell(bid, latestData[symbol] ? latestData[symbol].bid : bid);
        row.cells[2].innerHTML = getPriceCell(ask, latestData[symbol] ? latestData[symbol].ask : ask);

        latestData[symbol] = { bid, ask, dailyChange };
    });

    rowMap.forEach((row, symbol) => {
        if (!pageData.some(item => (item.symbol || item.Symbol || item.name || 'N/A') === symbol)) {
            tableBody.removeChild(row);
            rowMap.delete(symbol);
        }
    });

    updatePaginationButtons();
}

function getPriceCell(currentPrice, latestPrice) {
    currentPrice = Number(currentPrice);
    latestPrice = Number(latestPrice);

    if (isNaN(currentPrice)) return '<span>N/A</span>';

    const formattedPrice = currentPrice.toFixed(2);

    if (currentPrice < latestPrice) {
        return `<span class="green">${formattedPrice}</span>`;
    } else if (currentPrice > latestPrice) {
        return `<span class="red">${formattedPrice}</span>`;
    }
    return formattedPrice;
}

function getDailyChangeCell(currentChange, latestChange) {
    currentChange = Number(currentChange);
    latestChange = Number(latestChange);

    if (isNaN(currentChange)) return '<span>N/A</span>';

    const formattedChange = currentChange.toFixed(2);

    if (currentChange < latestChange) {
        return `<span class="green">${formattedChange}</span>`;
    } else if (currentChange > latestChange) {
        return `<span class="red">${formattedChange}</span>`;
    }
    return formattedChange;
}

function updatePaginationButtons() {
    const totalPages = Math.ceil(filteredData.length / rowsPerPage);
    const paginationDiv = document.querySelector('.pagination');
    paginationDiv.innerHTML = '';

    let startPage = 1;
    let endPage = Math.min(5, totalPages);

    if (currentPage > 3 && totalPages > 5) {
        startPage = currentPage - 2;
        endPage = Math.min(currentPage + 2, totalPages);
    }

    // Show the first page if it's not already shown
    if (startPage > 1) {
        createPaginationButton(1);
        if (startPage > 2) {
            const dots = document.createElement('span');
            dots.textContent = '...';
            paginationDiv.appendChild(dots);
        }
    }

    for (let i = startPage; i <= endPage; i++) {
        createPaginationButton(i);
    }

    // Show the last page if it's not already shown
    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            const dots = document.createElement('span');
            dots.textContent = '...';
            paginationDiv.appendChild(dots);
        }
        createPaginationButton(totalPages);
    }
}

function createPaginationButton(pageNumber) {
    const button = document.createElement('button');
    button.textContent = pageNumber;
    if (pageNumber === currentPage) {
        button.classList.add('active');
    }
    button.addEventListener('click', () => {
        currentPage = pageNumber;
        updateTable();
    });
    document.querySelector('.pagination').appendChild(button);
}

document.getElementById('searchInput').addEventListener('keyup', performSearch);

function performSearch() {
    const searchTerm = document.getElementById('searchInput').value.trim().toUpperCase();
    if (searchTerm) {
        clearInterval(intervalId);
        filteredData = allData.filter(item => {
            const symbol = (item.symbol || item.Symbol || item.name || 'N/A').toUpperCase();
            return symbol.includes(searchTerm);
        });
    } else {
        filteredData = [...allData];
        clearInterval(intervalId);
        intervalId = setInterval(fetchData, 1000);
    }
    currentPage = 1;
    updateTable();
}

intervalId = setInterval(fetchData, 1000);
fetchData();